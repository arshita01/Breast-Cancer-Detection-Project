from flask import Flask, render_template, request, redirect, url_for, session
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Load and prepare data
df = pd.read_csv("data.csv")
df = df.drop(columns=["Unnamed: 32"], errors='ignore')
df['diagnosis'] = LabelEncoder().fit_transform(df['diagnosis'])

# Ensure ID column exists
if 'id' not in df.columns:
    df['id'] = range(1, len(df) + 1)

X = df.drop(columns='diagnosis')
y = df['diagnosis']

# Train model
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)

users = {'admin': 'password123'}

@app.route('/', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if users.get(username) == password:
            session['username'] = username
            return redirect(url_for('choose'))
        else:
            error = 'Invalid credentials'
    return render_template('login.html', error=error)

@app.route('/choose', methods=['GET', 'POST'])
def choose():
    if 'username' not in session:
        return redirect(url_for('login'))

    patient_ids = df['id'].tolist()

    if request.method == 'POST':
        patient_type = request.form.get('patient_type')
        if patient_type == 'existing':
            patient_id = int(request.form.get('patient_id'))
            patient_row = df[df['id'] == patient_id]
            if not patient_row.empty:
                patient_data = patient_row[X.columns].values[0]
                result = predict_cancer_and_treatment(patient_data)
                return render_template('result.html', result=result)
        else:
            return redirect(url_for('new_patient_form'))

    return render_template('choose.html', patient_ids=patient_ids)

@app.route('/new', methods=['GET', 'POST'])
def new_patient_form():
    if 'username' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        user_input = [float(request.form[col]) for col in X.columns]
        result = predict_cancer_and_treatment(user_input)
        return render_template('result.html', result=result)

    return render_template('new_patient_form.html', columns=X.columns)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

def predict_cancer_and_treatment(user_input):
    prediction = clf.predict([user_input])[0]
    diagnosis = 'Malignant' if prediction == 1 else 'Benign'
    result = {'Diagnosis': diagnosis}

    if diagnosis == 'Malignant':
        area_mean = user_input[4]
        if area_mean < 500:
            stage = 'Stage I'; chemo = 4
        elif 500 <= area_mean <= 1000:
            stage = 'Stage II'; chemo = 6
        elif 1000 < area_mean <= 1500:
            stage = 'Stage III'; chemo = 8
        else:
            stage = 'Stage IV'; chemo = 10
        result['Stage'] = stage
        result['Recommended Chemo Sessions'] = chemo

    return result

if __name__ == '__main__':
    app.run(debug=True)
