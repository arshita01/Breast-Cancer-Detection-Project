import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load your dataset
df = pd.read_csv("data.csv")
df = df.drop(columns=["id", "Unnamed: 32"], errors='ignore')
df['diagnosis'] = df['diagnosis'].map({'M': 1, 'B': 0})

# Compute correlation matrix
corr = df.corr()
diagnosis_corr = corr[['diagnosis']].sort_values(by='diagnosis', ascending=False)

# Full correlation heatmap
plt.figure(figsize=(16, 12))
sns.heatmap(corr, annot=True, fmt=".2f", cmap='coolwarm', linewidths=0.5)
plt.title("Feature Correlation Heatmap")
plt.tight_layout()
plt.savefig("full_correlation_heatmap.png")
plt.close()

# Correlation with diagnosis
plt.figure(figsize=(8, 12))
sns.heatmap(diagnosis_corr, annot=True, cmap='coolwarm', linewidths=0.5)
plt.title("Feature Correlation with Diagnosis")
plt.tight_layout()
plt.savefig("diagnosis_correlation_heatmap.png")
plt.close()

print("Images saved as full_correlation_heatmap.png and diagnosis_correlation_heatmap.png")
