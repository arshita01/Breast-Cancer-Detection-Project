function sendMessage() {
    const input = document.getElementById("userInput");
    const message = input.value.trim();
    if (!message) return;

    const chatbox = document.getElementById("chatbox");
    chatbox.innerHTML += `<div><strong>You:</strong> ${message}</div>`;

    let reply = "I'm not sure how to respond to that.";

    const diagnosis = result.Diagnosis;
    const stage = result.Stage;

    if (message.toLowerCase().includes("suggestion") || message.toLowerCase().includes("do now")) {
        if (diagnosis === "Benign") {
            reply = "Since your result is benign, regular check-ups and a healthy lifestyle are key. Maintain a balanced diet and exercise regularly.";
        } else if (diagnosis === "Malignant") {
            reply = `As it's malignant (${stage}), it's important to follow up with your oncologist. Recommended chemo sessions are ${result["Recommended Chemo Sessions"]}. Stay strong, you're not alone.`;
        }
    } else if (message.toLowerCase().includes("diet")) {
        reply = "A high-fiber, low-fat diet rich in fruits and vegetables is generally recommended. Avoid processed foods.";
    } else if (message.toLowerCase().includes("exercise")) {
        reply = "Light to moderate activity like walking or yoga can be helpful. Always consult your doctor first.";
    } else if (message.toLowerCase().includes("hello") || message.toLowerCase().includes("hi")) {
        reply = "Hello! I'm here to give you suggestions based on your diagnosis. Ask me anything!";
    }else if (message.toLowerCase().includes("sleep")) {
        reply = "Aim for 7-9 hours of sleep each night to help your body heal and function well. Try to establish a consistent sleep schedule.";
    } else if (message.toLowerCase().includes("stress")) {
        reply = "Stress management techniques such as deep breathing, meditation, and mindfulness can be helpful. Consider relaxation exercises.";
    } else if (message.toLowerCase().includes("water") || message.toLowerCase().includes("hydration")) {
        reply = "Stay hydrated! Aim for 8 glasses of water a day, but more if you're active or in a hot environment.";
    } else if (message.toLowerCase().includes("medicine") || message.toLowerCase().includes("medication")) {
        reply = "Please follow your doctor's prescribed medication plan carefully and ask if you have any concerns about side effects.";
    } else if (message.toLowerCase().includes("symptoms")) {
        reply = "If you're experiencing new or worsening symptoms, please contact your healthcare provider for proper evaluation.";
    } else if (message.toLowerCase().includes("weight loss")) {
        reply = "Gradual weight loss through a balanced diet and regular exercise is the safest way. Consider speaking to a professional for guidance.";
    } else if (message.toLowerCase().includes("mental health")) {
        reply = "It's important to talk to a mental health professional if you're struggling emotionally. Therapy, counseling, and support groups can help.";
    } else if (message.toLowerCase().includes("vaccination")) {
        reply = "Vaccination is a key part of disease prevention. If you're unsure about which vaccines you need, consult your healthcare provider.";
    } else if (message.toLowerCase().includes("quit smoking") || message.toLowerCase().includes("stop smoking")) {
        reply = "Quitting smoking can improve your health significantly. Consider seeking professional help, support groups, or therapy to aid in quitting.";
    } else if (message.toLowerCase().includes("alcohol") || message.toLowerCase().includes("drinking")) {
        reply = "Limiting alcohol intake can be beneficial for overall health. Try to stay within recommended limits and consult your doctor if needed.";
    } else {
        reply = "I'm not sure how to help with that. Can you ask something else or clarify your question?";
    }

    chatbox.innerHTML += `<div><strong>Bot:</strong> ${reply}</div>`;
    chatbox.scrollTop = chatbox.scrollHeight;
    input.value = "";
}
